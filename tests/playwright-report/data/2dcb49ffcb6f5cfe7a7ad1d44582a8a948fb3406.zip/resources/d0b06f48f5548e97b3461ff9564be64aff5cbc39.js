import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Support.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/Support.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
export default function Support() {
  _s();
  const [messages, setMessages] = useState([]);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  useEffect(() => {
    fetch("http://localhost:4000/support").then((res) => res.json()).then((data) => setMessages(data));
  }, []);
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:4000/support", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: 1, subject, message })
    }).then((res) => res.json()).then((newMsg) => {
      setMessages([newMsg, ...messages]);
      setSubject("");
      setMessage("");
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Support" }, void 0, false, {
      fileName: "/app/src/pages/Support.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Subject",
          value: subject,
          onChange: (e) => setSubject(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/Support.jsx",
          lineNumber: 52,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          placeholder: "Message",
          value: message,
          onChange: (e) => setMessage(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/Support.jsx",
          lineNumber: 57,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Send" }, void 0, false, {
        fileName: "/app/src/pages/Support.jsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/Support.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { children: "Messages" }, void 0, false, {
      fileName: "/app/src/pages/Support.jsx",
      lineNumber: 65,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: messages.map(
      (m) => /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("b", { children: [
          m.subject,
          ":"
        ] }, void 0, true, {
          fileName: "/app/src/pages/Support.jsx",
          lineNumber: 69,
          columnNumber: 13
        }, this),
        " ",
        m.message
      ] }, m.id, true, {
        fileName: "/app/src/pages/Support.jsx",
        lineNumber: 68,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/pages/Support.jsx",
      lineNumber: 66,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/Support.jsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
}
_s(Support, "NycqUwUSpcR1JpIJo1su7r/apU0=");
_c = Support;
var _c;
$RefreshReg$(_c, "Support");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/Support.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/Support.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCTixPQUFPQSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFFM0Msd0JBQXdCQyxVQUFVO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlKLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNLLFNBQVNDLFVBQVUsSUFBSU4sU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ08sU0FBU0MsVUFBVSxJQUFJUixTQUFTLEVBQUU7QUFFekNELFlBQVUsTUFBTTtBQUNkVSxVQUFNLCtCQUErQixFQUNsQ0MsS0FBSyxDQUFBQyxRQUFPQSxJQUFJQyxLQUFLLENBQUMsRUFDdEJGLEtBQUssQ0FBQUcsU0FBUVQsWUFBWVMsSUFBSSxDQUFDO0FBQUEsRUFDbkMsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZUFBZUEsQ0FBQUMsTUFBSztBQUN4QkEsTUFBRUMsZUFBZTtBQUNqQlAsVUFBTSxpQ0FBaUM7QUFBQSxNQUNyQ1EsUUFBUTtBQUFBLE1BQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDOUNDLE1BQU1DLEtBQUtDLFVBQVUsRUFBRUMsUUFBUSxHQUFHakIsU0FBU0UsUUFBUSxDQUFDO0FBQUEsSUFDdEQsQ0FBQyxFQUNFRyxLQUFLLENBQUFDLFFBQU9BLElBQUlDLEtBQUssQ0FBQyxFQUN0QkYsS0FBSyxDQUFBYSxXQUFVO0FBQ2RuQixrQkFBWSxDQUFDbUIsUUFBUSxHQUFHcEIsUUFBUSxDQUFDO0FBQ2pDRyxpQkFBVyxFQUFFO0FBQ2JFLGlCQUFXLEVBQUU7QUFBQSxJQUNmLENBQUM7QUFBQSxFQUNMO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyx1QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVc7QUFBQSxJQUNYLHVCQUFDLFVBQUssVUFBVU0sY0FDZDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxhQUFZO0FBQUEsVUFDWixPQUFPVDtBQUFBQSxVQUNQLFVBQVUsQ0FBQVUsTUFBS1QsV0FBV1MsRUFBRVMsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFIMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzRDO0FBQUEsTUFFNUM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLGFBQVk7QUFBQSxVQUNaLE9BQU9sQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQVEsTUFBS1AsV0FBV08sRUFBRVMsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFIMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzRDO0FBQUEsTUFFNUMsdUJBQUMsWUFBTyxNQUFLLFVBQVMsb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxTQVg1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQyxRQUNFdEIsbUJBQVN1QjtBQUFBQSxNQUFJLENBQUFDLE1BQ1osdUJBQUMsUUFDQztBQUFBLCtCQUFDLE9BQUdBO0FBQUFBLFlBQUV0QjtBQUFBQSxVQUFRO0FBQUEsYUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUFJO0FBQUEsUUFBRXNCLEVBQUVwQjtBQUFBQSxXQURoQm9CLEVBQUVDLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFDMUIsR0FyRHVCRCxTQUFPO0FBQUE0QixLQUFQNUI7QUFBTyxJQUFBNEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTdXBwb3J0IiwiX3MiLCJtZXNzYWdlcyIsInNldE1lc3NhZ2VzIiwic3ViamVjdCIsInNldFN1YmplY3QiLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJkYXRhIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwidXNlcklkIiwibmV3TXNnIiwidGFyZ2V0IiwidmFsdWUiLCJtYXAiLCJtIiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlN1cHBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdXBwb3J0KCkge1xuICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW3N1YmplY3QsIHNldFN1YmplY3RdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDo0MDAwL3N1cHBvcnQnKVxuICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXG4gICAgICAudGhlbihkYXRhID0+IHNldE1lc3NhZ2VzKGRhdGEpKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDo0MDAwL3N1cHBvcnQnLCB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyB1c2VySWQ6IDEsIHN1YmplY3QsIG1lc3NhZ2UgfSlcbiAgICB9KVxuICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXG4gICAgICAudGhlbihuZXdNc2cgPT4ge1xuICAgICAgICBzZXRNZXNzYWdlcyhbbmV3TXNnLCAuLi5tZXNzYWdlc10pO1xuICAgICAgICBzZXRTdWJqZWN0KCcnKTtcbiAgICAgICAgc2V0TWVzc2FnZSgnJyk7XG4gICAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+U3VwcG9ydDwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGlucHV0IFxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU3ViamVjdFwiIFxuICAgICAgICAgIHZhbHVlPXtzdWJqZWN0fSBcbiAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTdWJqZWN0KGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgIC8+XG4gICAgICAgIDx0ZXh0YXJlYSBcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1lc3NhZ2VcIiBcbiAgICAgICAgICB2YWx1ZT17bWVzc2FnZX0gXG4gICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0TWVzc2FnZShlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAvPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5TZW5kPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG5cbiAgICAgIDxoMz5NZXNzYWdlczwvaDM+XG4gICAgICA8dWw+XG4gICAgICAgIHttZXNzYWdlcy5tYXAobSA9PiAoXG4gICAgICAgICAgPGxpIGtleT17bS5pZH0+XG4gICAgICAgICAgICA8Yj57bS5zdWJqZWN0fTo8L2I+IHttLm1lc3NhZ2V9XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9TdXBwb3J0LmpzeCJ9