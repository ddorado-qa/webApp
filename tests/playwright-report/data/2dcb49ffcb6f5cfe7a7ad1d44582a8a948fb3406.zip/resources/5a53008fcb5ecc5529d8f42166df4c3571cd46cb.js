import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/History.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/History.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
export default function History() {
  _s();
  const [history, setHistory] = useState([]);
  useEffect(() => {
    fetch("http://localhost:4000/history").then((res) => res.json()).then((data) => setHistory(data));
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "History" }, void 0, false, {
      fileName: "/app/src/pages/History.jsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    history.length === 0 ? /* @__PURE__ */ jsxDEV("p", { children: "No actions recorded." }, void 0, false, {
      fileName: "/app/src/pages/History.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("ul", { children: history.map(
      (item) => /* @__PURE__ */ jsxDEV("li", { children: [
        "[",
        item.timestamp,
        "] User ",
        item.userId,
        ": ",
        item.action
      ] }, item.id, true, {
        fileName: "/app/src/pages/History.jsx",
        lineNumber: 39,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/pages/History.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/History.jsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_s(History, "PUqjgfw0ccPwtx6QxD6fWqJYeMQ=");
_c = History;
var _c;
$RefreshReg$(_c, "History");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/History.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/History.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYk4sT0FBT0EsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBRTNDLHdCQUF3QkMsVUFBVTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJSixTQUFTLEVBQUU7QUFFekNELFlBQVUsTUFBTTtBQUNkTSxVQUFNLCtCQUErQixFQUNsQ0MsS0FBSyxDQUFBQyxRQUFPQSxJQUFJQyxLQUFLLENBQUMsRUFDdEJGLEtBQUssQ0FBQUcsU0FBUUwsV0FBV0ssSUFBSSxDQUFDO0FBQUEsRUFDbEMsR0FBRyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyx1QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVc7QUFBQSxJQUNWTixRQUFRTyxXQUFXLElBQ2xCLHVCQUFDLE9BQUUsb0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QixJQUV2Qix1QkFBQyxRQUNFUCxrQkFBUVE7QUFBQUEsTUFBSSxDQUFBQyxTQUNYLHVCQUFDLFFBQWdCO0FBQUE7QUFBQSxRQUNiQSxLQUFLQztBQUFBQSxRQUFVO0FBQUEsUUFBUUQsS0FBS0U7QUFBQUEsUUFBTztBQUFBLFFBQUdGLEtBQUtHO0FBQUFBLFdBRHRDSCxLQUFLSSxJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLElBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNkLEdBekJ1QkQsU0FBTztBQUFBZ0IsS0FBUGhCO0FBQU8sSUFBQWdCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiSGlzdG9yeSIsIl9zIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJmZXRjaCIsInRoZW4iLCJyZXMiLCJqc29uIiwiZGF0YSIsImxlbmd0aCIsIm1hcCIsIml0ZW0iLCJ0aW1lc3RhbXAiLCJ1c2VySWQiLCJhY3Rpb24iLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSGlzdG9yeS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhpc3RvcnkoKSB7XG4gIGNvbnN0IFtoaXN0b3J5LCBzZXRIaXN0b3J5XSA9IHVzZVN0YXRlKFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjQwMDAvaGlzdG9yeScpXG4gICAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAgIC50aGVuKGRhdGEgPT4gc2V0SGlzdG9yeShkYXRhKSk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+SGlzdG9yeTwvaDI+XG4gICAgICB7aGlzdG9yeS5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxwPk5vIGFjdGlvbnMgcmVjb3JkZWQuPC9wPlxuICAgICAgKSA6IChcbiAgICAgICAgPHVsPlxuICAgICAgICAgIHtoaXN0b3J5Lm1hcChpdGVtID0+IChcbiAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0uaWR9PlxuICAgICAgICAgICAgICBbe2l0ZW0udGltZXN0YW1wfV0gVXNlciB7aXRlbS51c2VySWR9OiB7aXRlbS5hY3Rpb259XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3VsPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvcGFnZXMvSGlzdG9yeS5qc3gifQ==