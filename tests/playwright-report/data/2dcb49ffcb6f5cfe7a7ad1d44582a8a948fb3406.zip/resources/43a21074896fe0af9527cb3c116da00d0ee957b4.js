import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Rating.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/Rating.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
export default function Rating() {
  _s();
  const [ratings, setRatings] = useState([]);
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState("");
  useEffect(() => {
    fetch("http://localhost:4000/rating").then((res) => res.json()).then((data) => setRatings(data));
  }, []);
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:4000/rating", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: 1, stars, comment })
    }).then((res) => res.json()).then((newRating) => {
      setRatings([newRating, ...ratings]);
      setStars(5);
      setComment("");
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Rate this App" }, void 0, false, {
      fileName: "/app/src/pages/Rating.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("label", { children: [
        "Stars:",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "number",
            min: "1",
            max: "5",
            value: stars,
            onChange: (e) => setStars(Number(e.target.value))
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/Rating.jsx",
            lineNumber: 54,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/pages/Rating.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          placeholder: "Comment",
          value: comment,
          onChange: (e) => setComment(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/Rating.jsx",
          lineNumber: 62,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Submit" }, void 0, false, {
        fileName: "/app/src/pages/Rating.jsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/Rating.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { children: "All Ratings" }, void 0, false, {
      fileName: "/app/src/pages/Rating.jsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: ratings.map(
      (r) => /* @__PURE__ */ jsxDEV("li", { children: [
        "⭐ ",
        r.stars,
        " - ",
        r.comment || "No comment"
      ] }, r.id, true, {
        fileName: "/app/src/pages/Rating.jsx",
        lineNumber: 73,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/pages/Rating.jsx",
      lineNumber: 71,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/Rating.jsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
}
_s(Rating, "BfZG9Gvj96SduzovIlKF8z5Aez8=");
_c = Rating;
var _c;
$RefreshReg$(_c, "Rating");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/Rating.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/Rating.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCTixPQUFPQSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFFM0Msd0JBQXdCQyxTQUFTO0FBQUFDLEtBQUE7QUFDL0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlKLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUNLLE9BQU9DLFFBQVEsSUFBSU4sU0FBUyxDQUFDO0FBQ3BDLFFBQU0sQ0FBQ08sU0FBU0MsVUFBVSxJQUFJUixTQUFTLEVBQUU7QUFFekNELFlBQVUsTUFBTTtBQUNkVSxVQUFNLDhCQUE4QixFQUNqQ0MsS0FBSyxDQUFBQyxRQUFPQSxJQUFJQyxLQUFLLENBQUMsRUFDdEJGLEtBQUssQ0FBQUcsU0FBUVQsV0FBV1MsSUFBSSxDQUFDO0FBQUEsRUFDbEMsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZUFBZUEsQ0FBQUMsTUFBSztBQUN4QkEsTUFBRUMsZUFBZTtBQUNqQlAsVUFBTSxnQ0FBZ0M7QUFBQSxNQUNwQ1EsUUFBUTtBQUFBLE1BQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDOUNDLE1BQU1DLEtBQUtDLFVBQVUsRUFBRUMsUUFBUSxHQUFHakIsT0FBT0UsUUFBUSxDQUFDO0FBQUEsSUFDcEQsQ0FBQyxFQUNFRyxLQUFLLENBQUFDLFFBQU9BLElBQUlDLEtBQUssQ0FBQyxFQUN0QkYsS0FBSyxDQUFBYSxjQUFhO0FBQ2pCbkIsaUJBQVcsQ0FBQ21CLFdBQVcsR0FBR3BCLE9BQU8sQ0FBQztBQUNsQ0csZUFBUyxDQUFDO0FBQ1ZFLGlCQUFXLEVBQUU7QUFBQSxJQUNmLENBQUM7QUFBQSxFQUNMO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBQUEsSUFDakIsdUJBQUMsVUFBSyxVQUFVTSxjQUNkO0FBQUEsNkJBQUMsV0FBSztBQUFBO0FBQUEsUUFFSjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsS0FBSTtBQUFBLFlBQ0osS0FBSTtBQUFBLFlBQ0osT0FBT1Q7QUFBQUEsWUFDUCxVQUFVLENBQUFVLE1BQUtULFNBQVNrQixPQUFPVCxFQUFFVSxPQUFPQyxLQUFLLENBQUM7QUFBQTtBQUFBLFVBTGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtrRDtBQUFBLFdBUHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLGFBQVk7QUFBQSxVQUNaLE9BQU9uQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQVEsTUFBS1AsV0FBV08sRUFBRVUsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFIMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzRDO0FBQUEsTUFFNUMsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQWhCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWU7QUFBQSxJQUNmLHVCQUFDLFFBQ0V2QixrQkFBUXdCO0FBQUFBLE1BQUksQ0FBQUMsTUFDWCx1QkFBQyxRQUFhO0FBQUE7QUFBQSxRQUNUQSxFQUFFdkI7QUFBQUEsUUFBTTtBQUFBLFFBQUl1QixFQUFFckIsV0FBVztBQUFBLFdBRHJCcUIsRUFBRUMsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsT0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQTtBQUVKO0FBQUMzQixHQTFEdUJELFFBQU07QUFBQTZCLEtBQU43QjtBQUFNLElBQUE2QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlJhdGluZyIsIl9zIiwicmF0aW5ncyIsInNldFJhdGluZ3MiLCJzdGFycyIsInNldFN0YXJzIiwiY29tbWVudCIsInNldENvbW1lbnQiLCJmZXRjaCIsInRoZW4iLCJyZXMiLCJqc29uIiwiZGF0YSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsInVzZXJJZCIsIm5ld1JhdGluZyIsIk51bWJlciIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiciIsImlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSYXRpbmcuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSYXRpbmcoKSB7XG4gIGNvbnN0IFtyYXRpbmdzLCBzZXRSYXRpbmdzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW3N0YXJzLCBzZXRTdGFyc10gPSB1c2VTdGF0ZSg1KTtcbiAgY29uc3QgW2NvbW1lbnQsIHNldENvbW1lbnRdID0gdXNlU3RhdGUoJycpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6NDAwMC9yYXRpbmcnKVxuICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXG4gICAgICAudGhlbihkYXRhID0+IHNldFJhdGluZ3MoZGF0YSkpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gZSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjQwMDAvcmF0aW5nJywge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlcklkOiAxLCBzdGFycywgY29tbWVudCB9KVxuICAgIH0pXG4gICAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAgIC50aGVuKG5ld1JhdGluZyA9PiB7XG4gICAgICAgIHNldFJhdGluZ3MoW25ld1JhdGluZywgLi4ucmF0aW5nc10pO1xuICAgICAgICBzZXRTdGFycyg1KTtcbiAgICAgICAgc2V0Q29tbWVudCgnJyk7XG4gICAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+UmF0ZSB0aGlzIEFwcDwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGxhYmVsPlxuICAgICAgICAgIFN0YXJzOlxuICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIiBcbiAgICAgICAgICAgIG1pbj1cIjFcIiBcbiAgICAgICAgICAgIG1heD1cIjVcIiBcbiAgICAgICAgICAgIHZhbHVlPXtzdGFyc30gXG4gICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTdGFycyhOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0gXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPHRleHRhcmVhIFxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29tbWVudFwiIFxuICAgICAgICAgIHZhbHVlPXtjb21tZW50fSBcbiAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRDb21tZW50KGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgIC8+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPlN1Ym1pdDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuXG4gICAgICA8aDM+QWxsIFJhdGluZ3M8L2gzPlxuICAgICAgPHVsPlxuICAgICAgICB7cmF0aW5ncy5tYXAociA9PiAoXG4gICAgICAgICAgPGxpIGtleT17ci5pZH0+XG4gICAgICAgICAgICDirZAge3Iuc3RhcnN9IC0ge3IuY29tbWVudCB8fCAnTm8gY29tbWVudCd9XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9SYXRpbmcuanN4In0=