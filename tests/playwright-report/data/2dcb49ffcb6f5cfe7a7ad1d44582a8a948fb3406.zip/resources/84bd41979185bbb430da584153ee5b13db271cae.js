import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Routes, Route, NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=7f70baf9";
import Home from "/src/pages/Home.jsx";
import Profile from "/src/pages/Profile.jsx";
import Settings from "/src/pages/Settings.jsx";
import History from "/src/pages/History.jsx";
import Support from "/src/pages/Support.jsx";
import Rating from "/src/pages/Rating.jsx";
export default function App() {
  const linkStyle = ({ isActive }) => ({
    marginRight: "0.75rem",
    textDecoration: "none",
    fontWeight: isActive ? "700" : "400"
  });
  return /* @__PURE__ */ jsxDEV("div", { style: { padding: "1rem", fontFamily: "system-ui, Arial, sans-serif" }, children: [
    /* @__PURE__ */ jsxDEV("nav", { style: { marginBottom: "1rem" }, children: [
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/", style: linkStyle, end: true, children: "Home" }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/profile", style: linkStyle, children: "Profile" }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/settings", style: linkStyle, children: "Settings" }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/history", style: linkStyle, children: "History" }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 44,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/support", style: linkStyle, children: "Support" }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/rating", style: linkStyle, children: "Rating" }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/App.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 50,
        columnNumber: 34
      }, this) }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/profile", element: /* @__PURE__ */ jsxDEV(Profile, {}, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 51,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/settings", element: /* @__PURE__ */ jsxDEV(Settings, {}, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 52,
        columnNumber: 42
      }, this) }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/history", element: /* @__PURE__ */ jsxDEV(History, {}, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 53,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/support", element: /* @__PURE__ */ jsxDEV(Support, {}, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 54,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/rating", element: /* @__PURE__ */ jsxDEV(Rating, {}, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 55,
        columnNumber: 40
      }, this) }, void 0, false, {
        fileName: "/app/src/App.jsx",
        lineNumber: 55,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/App.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/App.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBbkJSLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsUUFBUUMsT0FBT0MsZUFBZTtBQUN2QyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUVuQix3QkFBd0JDLE1BQU07QUFDNUIsUUFBTUMsWUFBWUEsQ0FBQyxFQUFFQyxTQUFTLE9BQU87QUFBQSxJQUNuQ0MsYUFBYTtBQUFBLElBQ2JDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZSCxXQUFXLFFBQVE7QUFBQSxFQUNqQztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVJLFNBQVMsUUFBUUMsWUFBWSwrQkFBK0IsR0FDeEU7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRUMsY0FBYyxPQUFPLEdBQ2pDO0FBQUEsNkJBQUMsV0FBUSxJQUFHLEtBQUksT0FBT1AsV0FBVyxLQUFHLE1BQUMsb0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEM7QUFBQSxNQUMxQyx1QkFBQyxXQUFRLElBQUcsWUFBVyxPQUFPQSxXQUFXLHVCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsTUFDaEQsdUJBQUMsV0FBUSxJQUFHLGFBQVksT0FBT0EsV0FBVyx3QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ2xELHVCQUFDLFdBQVEsSUFBRyxZQUFXLE9BQU9BLFdBQVcsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxNQUNoRCx1QkFBQyxXQUFRLElBQUcsWUFBVyxPQUFPQSxXQUFXLHVCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsTUFDaEQsdUJBQUMsV0FBUSxJQUFHLFdBQVUsT0FBT0EsV0FBVyxzQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLFNBTmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsVUFDQztBQUFBLDZCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUssS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVEsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLE1BQzVDLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVMsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLE1BQzlDLHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVEsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLE1BQzVDLHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVEsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLE1BQzVDLHVCQUFDLFNBQU0sTUFBSyxXQUFVLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU8sS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLFNBTjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDUSxLQTVCdUJUO0FBQUcsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiUm91dGVzIiwiUm91dGUiLCJOYXZMaW5rIiwiSG9tZSIsIlByb2ZpbGUiLCJTZXR0aW5ncyIsIkhpc3RvcnkiLCJTdXBwb3J0IiwiUmF0aW5nIiwiQXBwIiwibGlua1N0eWxlIiwiaXNBY3RpdmUiLCJtYXJnaW5SaWdodCIsInRleHREZWNvcmF0aW9uIiwiZm9udFdlaWdodCIsInBhZGRpbmciLCJmb250RmFtaWx5IiwibWFyZ2luQm90dG9tIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIExheW91dCBjb24gbmF2ZWdhY2nDs24geSBkZWZpbmljacOzbiBkZSBydXRhcy5cbi8vIEFob3JhIGluY2x1eWUgUmF0aW5nIHNpbiBlbGltaW5hciBuYWRhIGFudGVyaW9yLlxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFJvdXRlcywgUm91dGUsIE5hdkxpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCBIb21lIGZyb20gJy4vcGFnZXMvSG9tZSc7XG5pbXBvcnQgUHJvZmlsZSBmcm9tICcuL3BhZ2VzL1Byb2ZpbGUnO1xuaW1wb3J0IFNldHRpbmdzIGZyb20gJy4vcGFnZXMvU2V0dGluZ3MnO1xuaW1wb3J0IEhpc3RvcnkgZnJvbSAnLi9wYWdlcy9IaXN0b3J5JztcbmltcG9ydCBTdXBwb3J0IGZyb20gJy4vcGFnZXMvU3VwcG9ydCc7XG5pbXBvcnQgUmF0aW5nIGZyb20gJy4vcGFnZXMvUmF0aW5nJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBsaW5rU3R5bGUgPSAoeyBpc0FjdGl2ZSB9KSA9PiAoe1xuICAgIG1hcmdpblJpZ2h0OiAnMC43NXJlbScsXG4gICAgdGV4dERlY29yYXRpb246ICdub25lJyxcbiAgICBmb250V2VpZ2h0OiBpc0FjdGl2ZSA/ICc3MDAnIDogJzQwMCdcbiAgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcxcmVtJywgZm9udEZhbWlseTogJ3N5c3RlbS11aSwgQXJpYWwsIHNhbnMtc2VyaWYnIH19PlxuICAgICAgPG5hdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcxcmVtJyB9fT5cbiAgICAgICAgPE5hdkxpbmsgdG89XCIvXCIgc3R5bGU9e2xpbmtTdHlsZX0gZW5kPkhvbWU8L05hdkxpbms+XG4gICAgICAgIDxOYXZMaW5rIHRvPVwiL3Byb2ZpbGVcIiBzdHlsZT17bGlua1N0eWxlfT5Qcm9maWxlPC9OYXZMaW5rPlxuICAgICAgICA8TmF2TGluayB0bz1cIi9zZXR0aW5nc1wiIHN0eWxlPXtsaW5rU3R5bGV9PlNldHRpbmdzPC9OYXZMaW5rPlxuICAgICAgICA8TmF2TGluayB0bz1cIi9oaXN0b3J5XCIgc3R5bGU9e2xpbmtTdHlsZX0+SGlzdG9yeTwvTmF2TGluaz5cbiAgICAgICAgPE5hdkxpbmsgdG89XCIvc3VwcG9ydFwiIHN0eWxlPXtsaW5rU3R5bGV9PlN1cHBvcnQ8L05hdkxpbms+XG4gICAgICAgIDxOYXZMaW5rIHRvPVwiL3JhdGluZ1wiIHN0eWxlPXtsaW5rU3R5bGV9PlJhdGluZzwvTmF2TGluaz5cbiAgICAgIDwvbmF2PlxuXG4gICAgICA8Um91dGVzPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8SG9tZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvcHJvZmlsZVwiIGVsZW1lbnQ9ezxQcm9maWxlIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9zZXR0aW5nc1wiIGVsZW1lbnQ9ezxTZXR0aW5ncyAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvaGlzdG9yeVwiIGVsZW1lbnQ9ezxIaXN0b3J5IC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9zdXBwb3J0XCIgZWxlbWVudD17PFN1cHBvcnQgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JhdGluZ1wiIGVsZW1lbnQ9ezxSYXRpbmcgLz59IC8+XG4gICAgICA8L1JvdXRlcz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvQXBwLmpzeCJ9