import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Profile.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/Profile.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
export default function Profile() {
  _s();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch("http://localhost:4000/profile/1").then((res) => res.json()).then((data) => {
      setProfile(data);
      setLoading(false);
    });
  }, []);
  if (loading)
    return /* @__PURE__ */ jsxDEV("p", { children: "Loading profile..." }, void 0, false, {
      fileName: "/app/src/pages/Profile.jsx",
      lineNumber: 35,
      columnNumber: 23
    }, this);
  if (!profile)
    return /* @__PURE__ */ jsxDEV("p", { children: "No profile found" }, void 0, false, {
      fileName: "/app/src/pages/Profile.jsx",
      lineNumber: 36,
      columnNumber: 24
    }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Profile" }, void 0, false, {
      fileName: "/app/src/pages/Profile.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: [
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("b", { children: "Username:" }, void 0, false, {
          fileName: "/app/src/pages/Profile.jsx",
          lineNumber: 42,
          columnNumber: 13
        }, this),
        " ",
        profile.username
      ] }, void 0, true, {
        fileName: "/app/src/pages/Profile.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("b", { children: "Email:" }, void 0, false, {
          fileName: "/app/src/pages/Profile.jsx",
          lineNumber: 43,
          columnNumber: 13
        }, this),
        " ",
        profile.email
      ] }, void 0, true, {
        fileName: "/app/src/pages/Profile.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("b", { children: "Role:" }, void 0, false, {
          fileName: "/app/src/pages/Profile.jsx",
          lineNumber: 44,
          columnNumber: 13
        }, this),
        " ",
        profile.role
      ] }, void 0, true, {
        fileName: "/app/src/pages/Profile.jsx",
        lineNumber: 44,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("b", { children: "Subscribed:" }, void 0, false, {
          fileName: "/app/src/pages/Profile.jsx",
          lineNumber: 45,
          columnNumber: 13
        }, this),
        " ",
        profile.subscribed ? "Yes" : "No"
      ] }, void 0, true, {
        fileName: "/app/src/pages/Profile.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/Profile.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/Profile.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_s(Profile, "4MRkLCaQ845wrp3RuIKNpWGnSVM=");
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/Profile.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/Profile.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZXNCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWZ0QixPQUFPQSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFFM0Msd0JBQXdCQyxVQUFVO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlKLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNLLFNBQVNDLFVBQVUsSUFBSU4sU0FBUyxJQUFJO0FBRTNDRCxZQUFVLE1BQU07QUFDZFEsVUFBTSxpQ0FBaUMsRUFDcENDLEtBQUssQ0FBQUMsUUFBT0EsSUFBSUMsS0FBSyxDQUFDLEVBQ3RCRixLQUFLLENBQUFHLFNBQVE7QUFDWlAsaUJBQVdPLElBQUk7QUFDZkwsaUJBQVcsS0FBSztBQUFBLElBQ2xCLENBQUM7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUVMLE1BQUlEO0FBQVMsV0FBTyx1QkFBQyxPQUFFLGtDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUI7QUFDekMsTUFBSSxDQUFDRjtBQUFTLFdBQU8sdUJBQUMsT0FBRSxnQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CO0FBRXhDLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXO0FBQUEsSUFDWCx1QkFBQyxRQUNDO0FBQUEsNkJBQUMsUUFBRztBQUFBLCtCQUFDLE9BQUUseUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFBSTtBQUFBLFFBQUVBLFFBQVFTO0FBQUFBLFdBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUN2Qyx1QkFBQyxRQUFHO0FBQUEsK0JBQUMsT0FBRSxzQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVM7QUFBQSxRQUFJO0FBQUEsUUFBRVQsUUFBUVU7QUFBQUEsV0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ2pDLHVCQUFDLFFBQUc7QUFBQSwrQkFBQyxPQUFFLHFCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUTtBQUFBLFFBQUk7QUFBQSxRQUFFVixRQUFRVztBQUFBQSxXQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDL0IsdUJBQUMsUUFBRztBQUFBLCtCQUFDLE9BQUUsMkJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjO0FBQUEsUUFBSTtBQUFBLFFBQUVYLFFBQVFZLGFBQWEsUUFBUTtBQUFBLFdBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxTQUo1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUNiLEdBM0J1QkQsU0FBTztBQUFBZSxLQUFQZjtBQUFPLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiUHJvZmlsZSIsIl9zIiwicHJvZmlsZSIsInNldFByb2ZpbGUiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJkYXRhIiwidXNlcm5hbWUiLCJlbWFpbCIsInJvbGUiLCJzdWJzY3JpYmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9maWxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZmlsZSgpIHtcbiAgY29uc3QgW3Byb2ZpbGUsIHNldFByb2ZpbGVdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6NDAwMC9wcm9maWxlLzEnKVxuICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXG4gICAgICAudGhlbihkYXRhID0+IHtcbiAgICAgICAgc2V0UHJvZmlsZShkYXRhKTtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICB9KTtcbiAgfSwgW10pO1xuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPHA+TG9hZGluZyBwcm9maWxlLi4uPC9wPjtcbiAgaWYgKCFwcm9maWxlKSByZXR1cm4gPHA+Tm8gcHJvZmlsZSBmb3VuZDwvcD47XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPlByb2ZpbGU8L2gyPlxuICAgICAgPHVsPlxuICAgICAgICA8bGk+PGI+VXNlcm5hbWU6PC9iPiB7cHJvZmlsZS51c2VybmFtZX08L2xpPlxuICAgICAgICA8bGk+PGI+RW1haWw6PC9iPiB7cHJvZmlsZS5lbWFpbH08L2xpPlxuICAgICAgICA8bGk+PGI+Um9sZTo8L2I+IHtwcm9maWxlLnJvbGV9PC9saT5cbiAgICAgICAgPGxpPjxiPlN1YnNjcmliZWQ6PC9iPiB7cHJvZmlsZS5zdWJzY3JpYmVkID8gJ1llcycgOiAnTm8nfTwvbGk+XG4gICAgICA8L3VsPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9Qcm9maWxlLmpzeCJ9