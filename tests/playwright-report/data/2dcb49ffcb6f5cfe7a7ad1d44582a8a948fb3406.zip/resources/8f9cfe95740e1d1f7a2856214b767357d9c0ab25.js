import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Settings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/Settings.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
export default function Settings() {
  _s();
  const [settings, setSettings] = useState(null);
  useEffect(() => {
    fetch("http://localhost:4000/settings").then((res) => res.json()).then((data) => setSettings(data));
  }, []);
  const toggle = (key) => {
    const updated = { ...settings, [key]: !settings[key] };
    fetch("http://localhost:4000/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updated)
    }).then(() => setSettings(updated));
  };
  if (!settings)
    return /* @__PURE__ */ jsxDEV("p", { children: "Loading settings..." }, void 0, false, {
      fileName: "/app/src/pages/Settings.jsx",
      lineNumber: 40,
      columnNumber: 25
    }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Settings" }, void 0, false, {
      fileName: "/app/src/pages/Settings.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      "Dark Mode:",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => toggle("darkMode"), children: settings.darkMode ? "ON" : "OFF" }, void 0, false, {
        fileName: "/app/src/pages/Settings.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/Settings.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      "Notifications:",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => toggle("notifications"), children: settings.notifications ? "ON" : "OFF" }, void 0, false, {
        fileName: "/app/src/pages/Settings.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/Settings.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      "Language: ",
      settings.language
    ] }, void 0, true, {
      fileName: "/app/src/pages/Settings.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/Settings.jsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
}
_s(Settings, "mCc1AI3nlnFR6PXJot/5Z7AXrOM=");
_c = Settings;
var _c;
$RefreshReg$(_c, "Settings");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/Settings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/Settings.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0J3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnhCLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUUzQyx3QkFBd0JDLFdBQVc7QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUosU0FBUyxJQUFJO0FBRTdDRCxZQUFVLE1BQU07QUFDZE0sVUFBTSxnQ0FBZ0MsRUFDbkNDLEtBQUssQ0FBQUMsUUFBT0EsSUFBSUMsS0FBSyxDQUFDLEVBQ3RCRixLQUFLLENBQUFHLFNBQVFMLFlBQVlLLElBQUksQ0FBQztBQUFBLEVBQ25DLEdBQUcsRUFBRTtBQUVMLFFBQU1DLFNBQVNBLENBQUFDLFFBQU87QUFDcEIsVUFBTUMsVUFBVSxFQUFFLEdBQUdULFVBQVUsQ0FBQ1EsR0FBRyxHQUFHLENBQUNSLFNBQVNRLEdBQUcsRUFBRTtBQUNyRE4sVUFBTSxrQ0FBa0M7QUFBQSxNQUN0Q1EsUUFBUTtBQUFBLE1BQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDOUNDLE1BQU1DLEtBQUtDLFVBQVVMLE9BQU87QUFBQSxJQUM5QixDQUFDLEVBQUVOLEtBQUssTUFBTUYsWUFBWVEsT0FBTyxDQUFDO0FBQUEsRUFDcEM7QUFFQSxNQUFJLENBQUNUO0FBQVUsV0FBTyx1QkFBQyxPQUFFLG1DQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0I7QUFFNUMsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyx3QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxJQUNaLHVCQUFDLE9BQUM7QUFBQTtBQUFBLE1BRUEsdUJBQUMsWUFBTyxTQUFTLE1BQU1PLE9BQU8sVUFBVSxHQUNyQ1AsbUJBQVNlLFdBQVcsT0FBTyxTQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsT0FBQztBQUFBO0FBQUEsTUFFQSx1QkFBQyxZQUFPLFNBQVMsTUFBTVIsT0FBTyxlQUFlLEdBQzFDUCxtQkFBU2dCLGdCQUFnQixPQUFPLFNBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxNQUFXaEIsU0FBU2lCO0FBQUFBLFNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0M7QUFBQSxPQWRsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUE7QUFFSjtBQUFDbEIsR0F0Q3VCRCxVQUFRO0FBQUFvQixLQUFScEI7QUFBUSxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTZXR0aW5ncyIsIl9zIiwic2V0dGluZ3MiLCJzZXRTZXR0aW5ncyIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJkYXRhIiwidG9nZ2xlIiwia2V5IiwidXBkYXRlZCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRhcmtNb2RlIiwibm90aWZpY2F0aW9ucyIsImxhbmd1YWdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZXR0aW5ncy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNldHRpbmdzKCkge1xuICBjb25zdCBbc2V0dGluZ3MsIHNldFNldHRpbmdzXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6NDAwMC9zZXR0aW5ncycpXG4gICAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAgIC50aGVuKGRhdGEgPT4gc2V0U2V0dGluZ3MoZGF0YSkpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgdG9nZ2xlID0ga2V5ID0+IHtcbiAgICBjb25zdCB1cGRhdGVkID0geyAuLi5zZXR0aW5ncywgW2tleV06ICFzZXR0aW5nc1trZXldIH07XG4gICAgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6NDAwMC9zZXR0aW5ncycsIHtcbiAgICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHVwZGF0ZWQpXG4gICAgfSkudGhlbigoKSA9PiBzZXRTZXR0aW5ncyh1cGRhdGVkKSk7XG4gIH07XG5cbiAgaWYgKCFzZXR0aW5ncykgcmV0dXJuIDxwPkxvYWRpbmcgc2V0dGluZ3MuLi48L3A+O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5TZXR0aW5nczwvaDI+XG4gICAgICA8cD5cbiAgICAgICAgRGFyayBNb2RlOiBcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB0b2dnbGUoJ2RhcmtNb2RlJyl9PlxuICAgICAgICAgIHtzZXR0aW5ncy5kYXJrTW9kZSA/ICdPTicgOiAnT0ZGJ31cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L3A+XG4gICAgICA8cD5cbiAgICAgICAgTm90aWZpY2F0aW9uczogXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gdG9nZ2xlKCdub3RpZmljYXRpb25zJyl9PlxuICAgICAgICAgIHtzZXR0aW5ncy5ub3RpZmljYXRpb25zID8gJ09OJyA6ICdPRkYnfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvcD5cbiAgICAgIDxwPkxhbmd1YWdlOiB7c2V0dGluZ3MubGFuZ3VhZ2V9PC9wPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9TZXR0aW5ncy5qc3gifQ==