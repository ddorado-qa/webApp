import {
  require_react
} from "/node_modules/.vite/deps/chunk-WQMOH32Y.js?v=f4dc7e21";
import "/node_modules/.vite/deps/chunk-5WWUZCGV.js?v=f4dc7e21";
export default require_react();
//# sourceMappingURL=react.js.map
