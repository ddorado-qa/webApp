import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UsersManager.jsx");import.meta.env = {"VITE_API_URL":"http://localhost:4000","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=52ec5c9e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/UsersManager.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=52ec5c9e"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import axios from "/node_modules/.vite/deps/axios.js?v=49c78cd1";
const API = import.meta.env.VITE_API_URL || "http://localhost:4000";
export default function UsersManager() {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [users, setUsers] = useState([]);
  const [role, setRole] = useState("user");
  const [subscribe, setSubscribe] = useState(false);
  const [editId, setEditId] = useState(null);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await axios.get(`${API}/users`);
        setUsers(res.data || []);
      } catch (e) {
        setUsers([]);
      }
    };
    fetchUsers();
  }, [message]);
  const handleRegisterOrUpdate = async () => {
    try {
      if (editId) {
        const res = await axios.put(`${API}/users/${editId}`, { username, password });
        setMessage(`Updated user: ${res.data.username}`);
      } else {
        const res = await axios.post(`${API}/register`, { username, password });
        setMessage(`Registered user: ${res.data.username}`);
      }
      setUsername("");
      setPassword("");
      setEditId(null);
    } catch (err) {
      setMessage(err.response?.data?.error || "Error during save");
    }
  };
  const handleLogin = async () => {
    try {
      const res = await axios.post(`${API}/login`, { username, password });
      setMessage(`Logged in as: ${res.data.username}`);
      setUsername("");
      setPassword("");
    } catch (err) {
      setMessage(err.response?.data?.error || "Error during login");
    }
  };
  const handleEdit = (user) => {
    setUsername(user.username);
    setPassword("");
    setEditId(user.id);
  };
  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API}/users/${id}`);
      setMessage(`Deleted user with id: ${id}`);
    } catch (err) {
      setMessage(err.response?.data?.error || "Error during delete");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
    /* @__PURE__ */ jsxDEV("h1", { "datatest-id": "title", children: "Microfrontend Starter" }, void 0, false, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "username", children: "Username" }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 105,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id: "username",
          "datatest-id": "username",
          placeholder: "Username",
          value: username,
          onChange: (e) => setUsername(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 106,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "password", children: "Password" }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id: "password",
          "datatest-id": "password",
          type: "password",
          placeholder: "Password",
          value: password,
          onChange: (e) => setPassword(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 117,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "role", children: "Role (select)" }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          id: "role",
          "datatest-id": "roleSelect",
          value: role,
          onChange: (e) => setRole(e.target.value),
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "user", children: "User" }, void 0, false, {
              fileName: "/app/src/components/UsersManager.jsx",
              lineNumber: 135,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "admin", children: "Admin" }, void 0, false, {
              fileName: "/app/src/components/UsersManager.jsx",
              lineNumber: 136,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 129,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "row", children: /* @__PURE__ */ jsxDEV("label", { children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          "datatest-id": "subscribeToggle",
          type: "checkbox",
          checked: subscribe,
          onChange: (e) => setSubscribe(e.target.checked)
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 142,
          columnNumber: 11
        },
        this
      ),
      "Subscribe to newsletter"
    ] }, void 0, true, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 141,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 140,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "1rem" }, className: "row", children: [
      /* @__PURE__ */ jsxDEV("button", { "datatest-id": "registerBtn", onClick: handleRegisterOrUpdate, children: editId ? "Update" : "Register" }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 153,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "datatest-id": "loginBtn", onClick: handleLogin, style: { marginLeft: "1rem" }, children: "Login" }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 156,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "1rem" }, "datatest-id": "message", className: "row", children: message }, void 0, false, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 161,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 165,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "Users" }, void 0, false, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 167,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("table", { "datatest-id": "usersTable", style: { width: "100%", borderCollapse: "collapse" }, children: [
      /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { children: "#" }, void 0, false, {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 170,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { children: "Username" }, void 0, false, {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 170,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("th", { children: "Actions" }, void 0, false, {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 170,
          columnNumber: 42
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 170,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 169,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { children: users.map(
        (u) => /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { children: u.id }, void 0, false, {
            fileName: "/app/src/components/UsersManager.jsx",
            lineNumber: 175,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: u.username }, void 0, false, {
            fileName: "/app/src/components/UsersManager.jsx",
            lineNumber: 176,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => handleEdit(u), children: "Edit" }, void 0, false, {
              fileName: "/app/src/components/UsersManager.jsx",
              lineNumber: 178,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(u.id), style: { marginLeft: "0.5rem" }, children: "Delete" }, void 0, false, {
              fileName: "/app/src/components/UsersManager.jsx",
              lineNumber: 179,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/UsersManager.jsx",
            lineNumber: 177,
            columnNumber: 15
          }, this)
        ] }, u.id, true, {
          fileName: "/app/src/components/UsersManager.jsx",
          lineNumber: 174,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/components/UsersManager.jsx",
        lineNumber: 172,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/UsersManager.jsx",
      lineNumber: 168,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/UsersManager.jsx",
    lineNumber: 100,
    columnNumber: 5
  }, this);
}
_s(UsersManager, "Q+Q1ko07oRwZMR9/5/2TfMhY8Bo=");
_c = UsersManager;
var _c;
$RefreshReg$(_c, "UsersManager");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/UsersManager.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/UsersManager.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlFTixPQUFPQSxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDM0MsT0FBT0MsV0FBVztBQUdsQixNQUFNQyxNQUFNQyxZQUFZQyxJQUFJQyxnQkFBZ0I7QUFFNUMsd0JBQXdCQyxlQUFlO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlWLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNXLFVBQVVDLFdBQVcsSUFBSVosU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2EsU0FBU0MsVUFBVSxJQUFJZCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDZSxPQUFPQyxRQUFRLElBQUloQixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxNQUFNO0FBQ3ZDLFFBQU0sQ0FBQ21CLFdBQVdDLFlBQVksSUFBSXBCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxQixRQUFRQyxTQUFTLElBQUl0QixTQUFTLElBQUk7QUFHekNDLFlBQVUsTUFBTTtBQUNkLFVBQU1zQixhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGLGNBQU1DLE1BQU0sTUFBTXRCLE1BQU11QixJQUFJLEdBQUd0QixHQUFHLFFBQVE7QUFDMUNhLGlCQUFTUSxJQUFJRSxRQUFRLEVBQUU7QUFBQSxNQUN6QixTQUFTQyxHQUFHO0FBQ1ZYLGlCQUFTLEVBQUU7QUFBQSxNQUNiO0FBQUEsSUFDRjtBQUNBTyxlQUFXO0FBQUEsRUFDYixHQUFHLENBQUNWLE9BQU8sQ0FBQztBQUdaLFFBQU1lLHlCQUF5QixZQUFZO0FBQ3pDLFFBQUk7QUFDRixVQUFJUCxRQUFRO0FBQ1YsY0FBTUcsTUFBTSxNQUFNdEIsTUFBTTJCLElBQUksR0FBRzFCLEdBQUcsVUFBVWtCLE1BQU0sSUFBSSxFQUFFWixVQUFVRSxTQUFTLENBQUM7QUFDNUVHLG1CQUFXLGlCQUFpQlUsSUFBSUUsS0FBS2pCLFFBQVEsRUFBRTtBQUFBLE1BQ2pELE9BQU87QUFDTCxjQUFNZSxNQUFNLE1BQU10QixNQUFNNEIsS0FBSyxHQUFHM0IsR0FBRyxhQUFhLEVBQUVNLFVBQVVFLFNBQVMsQ0FBQztBQUN0RUcsbUJBQVcsb0JBQW9CVSxJQUFJRSxLQUFLakIsUUFBUSxFQUFFO0FBQUEsTUFDcEQ7QUFDQUMsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2RVLGdCQUFVLElBQUk7QUFBQSxJQUNoQixTQUFTUyxLQUFLO0FBQ1pqQixpQkFBV2lCLElBQUlDLFVBQVVOLE1BQU1PLFNBQVMsbUJBQW1CO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBR0EsUUFBTUMsY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNVixNQUFNLE1BQU10QixNQUFNNEIsS0FBSyxHQUFHM0IsR0FBRyxVQUFVLEVBQUVNLFVBQVVFLFNBQVMsQ0FBQztBQUNuRUcsaUJBQVcsaUJBQWlCVSxJQUFJRSxLQUFLakIsUUFBUSxFQUFFO0FBQy9DQyxrQkFBWSxFQUFFO0FBQ2RFLGtCQUFZLEVBQUU7QUFBQSxJQUNoQixTQUFTbUIsS0FBSztBQUNaakIsaUJBQVdpQixJQUFJQyxVQUFVTixNQUFNTyxTQUFTLG9CQUFvQjtBQUFBLElBQzlEO0FBQUEsRUFDRjtBQUdBLFFBQU1FLGFBQWFBLENBQUNDLFNBQVM7QUFDM0IxQixnQkFBWTBCLEtBQUszQixRQUFRO0FBQ3pCRyxnQkFBWSxFQUFFO0FBQ2RVLGNBQVVjLEtBQUtDLEVBQUU7QUFBQSxFQUNuQjtBQUdBLFFBQU1DLGVBQWUsT0FBT0QsT0FBTztBQUNqQyxRQUFJO0FBQ0YsWUFBTW5DLE1BQU1xQyxPQUFPLEdBQUdwQyxHQUFHLFVBQVVrQyxFQUFFLEVBQUU7QUFDdkN2QixpQkFBVyx5QkFBeUJ1QixFQUFFLEVBQUU7QUFBQSxJQUMxQyxTQUFTTixLQUFLO0FBQ1pqQixpQkFBV2lCLElBQUlDLFVBQVVOLE1BQU1PLFNBQVMscUJBQXFCO0FBQUEsSUFDL0Q7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLDJCQUFDLFFBQUcsZUFBWSxTQUFRLHFDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDO0FBQUEsSUFFN0MsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSw2QkFBQyxXQUFNLFNBQVEsWUFBVyx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxlQUFZO0FBQUEsVUFDWixhQUFZO0FBQUEsVUFDWixPQUFPeEI7QUFBQUEsVUFDUCxVQUFVLENBQUFrQixNQUFLakIsWUFBWWlCLEVBQUVhLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBTDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUs2QztBQUFBLFNBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSw2QkFBQyxXQUFNLFNBQVEsWUFBVyx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxlQUFZO0FBQUEsVUFDWixNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixPQUFPOUI7QUFBQUEsVUFDUCxVQUFVLENBQUFnQixNQUFLZixZQUFZZSxFQUFFYSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQU4zQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNNkM7QUFBQSxTQVIvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsNkJBQUMsV0FBTSxTQUFRLFFBQU8sNkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUNuQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsZUFBWTtBQUFBLFVBQ1osT0FBT3hCO0FBQUFBLFVBQ1AsVUFBVSxDQUFBVSxNQUFLVCxRQUFRUyxFQUFFYSxPQUFPQyxLQUFLO0FBQUEsVUFFckM7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUN6Qix1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQTtBQUFBO0FBQUEsUUFQN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsV0FDQztBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxlQUFZO0FBQUEsVUFDWixNQUFLO0FBQUEsVUFDTCxTQUFTdEI7QUFBQUEsVUFDVCxVQUFVLENBQUFRLE1BQUtQLGFBQWFPLEVBQUVhLE9BQU9FLE9BQU87QUFBQTtBQUFBLFFBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlnRDtBQUFBO0FBQUEsU0FMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsV0FBVyxPQUFPLEdBQUcsV0FBVSxPQUMzQztBQUFBLDZCQUFDLFlBQU8sZUFBWSxlQUFjLFNBQVNmLHdCQUN4Q1AsbUJBQVMsV0FBVyxjQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sZUFBWSxZQUFXLFNBQVNhLGFBQWEsT0FBTyxFQUFFVSxZQUFZLE9BQU8sR0FBRSxxQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFRCxXQUFXLE9BQU8sR0FBRyxlQUFZLFdBQVUsV0FBVSxPQUNoRTlCLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUVILHVCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxXQUFNLGVBQVksY0FBYSxPQUFPLEVBQUVnQyxPQUFPLFFBQVFDLGdCQUFnQixXQUFXLEdBQ2pGO0FBQUEsNkJBQUMsV0FDQyxpQ0FBQyxRQUFHO0FBQUEsK0JBQUMsUUFBRyxpQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxRQUFLLHVCQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFBSyx1QkFBQyxRQUFHLHVCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFdBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxXQUNFL0IsZ0JBQU1nQztBQUFBQSxRQUFJLENBQUFDLE1BQ1QsdUJBQUMsUUFDQztBQUFBLGlDQUFDLFFBQUlBLFlBQUVYLE1BQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVTtBQUFBLFVBQ1YsdUJBQUMsUUFBSVcsWUFBRXZDLFlBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUNoQix1QkFBQyxRQUNDO0FBQUEsbUNBQUMsWUFBTyxTQUFTLE1BQU0wQixXQUFXYSxDQUFDLEdBQUcsb0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFDMUMsdUJBQUMsWUFBTyxTQUFTLE1BQU1WLGFBQWFVLEVBQUVYLEVBQUUsR0FBRyxPQUFPLEVBQUVPLFlBQVksU0FBUyxHQUFHLHNCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLGVBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQU5PSSxFQUFFWCxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLE1BQ0QsS0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUZBO0FBRUo7QUFBQzdCLEdBN0p1QkQsY0FBWTtBQUFBMEMsS0FBWjFDO0FBQVksSUFBQTBDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiYXhpb3MiLCJBUEkiLCJpbXBvcnQiLCJlbnYiLCJWSVRFX0FQSV9VUkwiLCJVc2Vyc01hbmFnZXIiLCJfcyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ1c2VycyIsInNldFVzZXJzIiwicm9sZSIsInNldFJvbGUiLCJzdWJzY3JpYmUiLCJzZXRTdWJzY3JpYmUiLCJlZGl0SWQiLCJzZXRFZGl0SWQiLCJmZXRjaFVzZXJzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImUiLCJoYW5kbGVSZWdpc3Rlck9yVXBkYXRlIiwicHV0IiwicG9zdCIsImVyciIsInJlc3BvbnNlIiwiZXJyb3IiLCJoYW5kbGVMb2dpbiIsImhhbmRsZUVkaXQiLCJ1c2VyIiwiaWQiLCJoYW5kbGVEZWxldGUiLCJkZWxldGUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImNoZWNrZWQiLCJtYXJnaW5Ub3AiLCJtYXJnaW5MZWZ0Iiwid2lkdGgiLCJib3JkZXJDb2xsYXBzZSIsIm1hcCIsInUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJzTWFuYWdlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXN0ZSBjb21wb25lbnRlIGNvbnRpZW5lIFRPRE8gbG8gcXVlIHRlbsOtYXMgZW4gdHUgQXBwLmpzeCBvcmlnaW5hbCxcbi8vIGluY2x1aWRvIGVsIENSVUQgZGUgdXN1YXJpb3MgeSBsb2dpbi4gU2UgbWFudGllbmUgbGEgY29tcGF0aWJpbGlkYWRcbi8vIGNvbiBsb3MgZGF0YXRlc3QtaWQgdXNhZG9zIGVuIGxvcyB0ZXN0cyBkZSBQbGF5d3JpZ2h0LlxuXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XG5cbi8vIFVzYW1vcyBsYSB2YXJpYWJsZSBkZSBlbnRvcm5vIFZJVEVfQVBJX1VSTCAodml0ZSBleHBvbmUgVklURV8qIGVuIGltcG9ydC5tZXRhLmVudilcbmNvbnN0IEFQSSA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9VUkwgfHwgJ2h0dHA6Ly9sb2NhbGhvc3Q6NDAwMCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFVzZXJzTWFuYWdlcigpIHtcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSB1c2VTdGF0ZSgndXNlcicpO1xuICBjb25zdCBbc3Vic2NyaWJlLCBzZXRTdWJzY3JpYmVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdElkLCBzZXRFZGl0SWRdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgLy8gUmVmcmVzY2FyIGxpc3RhIGN1YW5kbyBjYW1iaWUgbWVzc2FnZSAobWlzbWEgbMOzZ2ljYSBxdWUgdGVuw61hcylcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXhpb3MuZ2V0KGAke0FQSX0vdXNlcnNgKTtcbiAgICAgICAgc2V0VXNlcnMocmVzLmRhdGEgfHwgW10pO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBzZXRVc2VycyhbXSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBmZXRjaFVzZXJzKCk7XG4gIH0sIFttZXNzYWdlXSk7XG5cbiAgLy8gUmVnaXN0cmFyIG8gYWN0dWFsaXphciAobWFudGllbmUgY29tcGF0aWJpbGlkYWQgY29uIHR1IGZsdWpvKVxuICBjb25zdCBoYW5kbGVSZWdpc3Rlck9yVXBkYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBpZiAoZWRpdElkKSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF4aW9zLnB1dChgJHtBUEl9L3VzZXJzLyR7ZWRpdElkfWAsIHsgdXNlcm5hbWUsIHBhc3N3b3JkIH0pO1xuICAgICAgICBzZXRNZXNzYWdlKGBVcGRhdGVkIHVzZXI6ICR7cmVzLmRhdGEudXNlcm5hbWV9YCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBheGlvcy5wb3N0KGAke0FQSX0vcmVnaXN0ZXJgLCB7IHVzZXJuYW1lLCBwYXNzd29yZCB9KTtcbiAgICAgICAgc2V0TWVzc2FnZShgUmVnaXN0ZXJlZCB1c2VyOiAke3Jlcy5kYXRhLnVzZXJuYW1lfWApO1xuICAgICAgfVxuICAgICAgc2V0VXNlcm5hbWUoJycpO1xuICAgICAgc2V0UGFzc3dvcmQoJycpO1xuICAgICAgc2V0RWRpdElkKG51bGwpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0TWVzc2FnZShlcnIucmVzcG9uc2U/LmRhdGE/LmVycm9yIHx8ICdFcnJvciBkdXJpbmcgc2F2ZScpO1xuICAgIH1cbiAgfTtcblxuICAvLyBMb2dpblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXhpb3MucG9zdChgJHtBUEl9L2xvZ2luYCwgeyB1c2VybmFtZSwgcGFzc3dvcmQgfSk7XG4gICAgICBzZXRNZXNzYWdlKGBMb2dnZWQgaW4gYXM6ICR7cmVzLmRhdGEudXNlcm5hbWV9YCk7XG4gICAgICBzZXRVc2VybmFtZSgnJyk7XG4gICAgICBzZXRQYXNzd29yZCgnJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRNZXNzYWdlKGVyci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgJ0Vycm9yIGR1cmluZyBsb2dpbicpO1xuICAgIH1cbiAgfTtcblxuICAvLyBFZGl0YXIgKGNhcmdhciBkYXRvcyBlbiBlbCBmb3JtdWxhcmlvKVxuICBjb25zdCBoYW5kbGVFZGl0ID0gKHVzZXIpID0+IHtcbiAgICBzZXRVc2VybmFtZSh1c2VyLnVzZXJuYW1lKTtcbiAgICBzZXRQYXNzd29yZCgnJyk7XG4gICAgc2V0RWRpdElkKHVzZXIuaWQpO1xuICB9O1xuXG4gIC8vIEVsaW1pbmFyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBheGlvcy5kZWxldGUoYCR7QVBJfS91c2Vycy8ke2lkfWApO1xuICAgICAgc2V0TWVzc2FnZShgRGVsZXRlZCB1c2VyIHdpdGggaWQ6ICR7aWR9YCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRNZXNzYWdlKGVyci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgJ0Vycm9yIGR1cmluZyBkZWxldGUnKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgey8qIE1hbnRlbmdvIGVsIG1pc21vIHTDrXR1bG8geSBkYXRhdGVzdC1pZCBxdWUgdHVzIHRlc3RzIGVzcGVyYW4gKi99XG4gICAgICA8aDEgZGF0YXRlc3QtaWQ9XCJ0aXRsZVwiPk1pY3JvZnJvbnRlbmQgU3RhcnRlcjwvaDE+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwidXNlcm5hbWVcIj5Vc2VybmFtZTwvbGFiZWw+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGlkPVwidXNlcm5hbWVcIlxuICAgICAgICAgIGRhdGF0ZXN0LWlkPVwidXNlcm5hbWVcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVXNlcm5hbWVcIlxuICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiPlBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgZGF0YXRlc3QtaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBhc3N3b3JkXCJcbiAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwicm9sZVwiPlJvbGUgKHNlbGVjdCk8L2xhYmVsPlxuICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgaWQ9XCJyb2xlXCJcbiAgICAgICAgICBkYXRhdGVzdC1pZD1cInJvbGVTZWxlY3RcIlxuICAgICAgICAgIHZhbHVlPXtyb2xlfVxuICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFJvbGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICA+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInVzZXJcIj5Vc2VyPC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFkbWluXCI+QWRtaW48L29wdGlvbj5cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cbiAgICAgICAgPGxhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YXRlc3QtaWQ9XCJzdWJzY3JpYmVUb2dnbGVcIlxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgIGNoZWNrZWQ9e3N1YnNjcmliZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFN1YnNjcmliZShlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIFN1YnNjcmliZSB0byBuZXdzbGV0dGVyXG4gICAgICAgIDwvbGFiZWw+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6ICcxcmVtJyB9fSBjbGFzc05hbWU9XCJyb3dcIj5cbiAgICAgICAgPGJ1dHRvbiBkYXRhdGVzdC1pZD1cInJlZ2lzdGVyQnRuXCIgb25DbGljaz17aGFuZGxlUmVnaXN0ZXJPclVwZGF0ZX0+XG4gICAgICAgICAge2VkaXRJZCA/ICdVcGRhdGUnIDogJ1JlZ2lzdGVyJ31cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b24gZGF0YXRlc3QtaWQ9XCJsb2dpbkJ0blwiIG9uQ2xpY2s9e2hhbmRsZUxvZ2lufSBzdHlsZT17eyBtYXJnaW5MZWZ0OiAnMXJlbScgfX0+XG4gICAgICAgICAgTG9naW5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6ICcxcmVtJyB9fSBkYXRhdGVzdC1pZD1cIm1lc3NhZ2VcIiBjbGFzc05hbWU9XCJyb3dcIj5cbiAgICAgICAge21lc3NhZ2V9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGhyIC8+XG5cbiAgICAgIDxoMj5Vc2VyczwvaDI+XG4gICAgICA8dGFibGUgZGF0YXRlc3QtaWQ9XCJ1c2Vyc1RhYmxlXCIgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJywgYm9yZGVyQ29sbGFwc2U6ICdjb2xsYXBzZScgfX0+XG4gICAgICAgIDx0aGVhZD5cbiAgICAgICAgICA8dHI+PHRoPiM8L3RoPjx0aD5Vc2VybmFtZTwvdGg+PHRoPkFjdGlvbnM8L3RoPjwvdHI+XG4gICAgICAgIDwvdGhlYWQ+XG4gICAgICAgIDx0Ym9keT5cbiAgICAgICAgICB7dXNlcnMubWFwKHUgPT4gKFxuICAgICAgICAgICAgPHRyIGtleT17dS5pZH0+XG4gICAgICAgICAgICAgIDx0ZD57dS5pZH08L3RkPlxuICAgICAgICAgICAgICA8dGQ+e3UudXNlcm5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRWRpdCh1KX0+RWRpdDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKHUuaWQpfSBzdHlsZT17eyBtYXJnaW5MZWZ0OiAnMC41cmVtJyB9fT5EZWxldGU8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL1VzZXJzTWFuYWdlci5qc3gifQ==